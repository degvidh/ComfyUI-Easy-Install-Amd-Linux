Create an empty file named "keep_cache.flag" in this folder to keep the
downloaded pip/uv package cache between installs and updates.
This speeds up reinstalls and uses less bandwidth, at the cost of disk space.
