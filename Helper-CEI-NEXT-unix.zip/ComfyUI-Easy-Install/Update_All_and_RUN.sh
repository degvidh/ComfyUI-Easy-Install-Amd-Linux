#!/bin/bash

cd "$(dirname "$0")"

# Set colors (re-define for standalone execution if needed, or assume sourced)
WARNING='\033[33m'
RED='\033[91m'
GREEN='\033[92m'
YELLOW='\033[93m'
BOLD='\033[1m'
RESET='\033[0m'

# Prevent git credential prompts during unattended node updates
export GIT_TERMINAL_PROMPT=0
export GIT_ASKPASS=echo
export GCM_INTERACTIVE=never

# Set arguments (re-define for standalone execution if needed, or assume sourced)
UV_NC="--no-cache"
if [ -f "Add-Ons/Tools/Helper-CEI/keep_cache.flag" ]; then UV_NC=""; fi
UV_ARGS="$UV_NC --link-mode=copy"

# Detect embedded Python
echo -e "${GREEN}🔍 Detecting Python environment...${RESET}"
PYTHON_BIN=""

if [ -f "python_embeded/python" ]; then
    PYTHON_BIN="./python_embeded/python"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
elif [ -f "python_embeded/bin/python3" ]; then
    PYTHON_BIN="./python_embeded/bin/python3"
    echo -e "${GREEN}   ✓ Found Python 3 (embedded)${RESET}"
elif [ -f "python_embeded/bin/python" ]; then
    PYTHON_BIN="./python_embeded/bin/python"
    echo -e "${GREEN}   ✓ Found Python (embedded)${RESET}"
fi

if [ -z "$PYTHON_BIN" ]; then
    echo -e "${RED}Error: Embedded Python not found!${RESET}"
    echo -e "${YELLOW}Expected: python_embeded/python${RESET}"
    exit 1
fi

echo -e "${GREEN}🐍 Using: ${YELLOW}${PYTHON_BIN}${RESET}"
echo ""

echo -e "${GREEN}::::::::::::::: Updating ComfyUI :::::::::::::::${RESET}"
echo ""
cd ./update && bash update_comfyui.sh nopause && cd ..
echo ""

# Erasing ~* folders in the current venv's site-packages
VENV_SITE_PACKAGES=$("$PYTHON_BIN" -c "import site; print(site.getsitepackages()[0])")
if [ -d "$VENV_SITE_PACKAGES" ]; then
    find "$VENV_SITE_PACKAGES" -maxdepth 1 -type d -name '~*' -exec rm -rf {} + 2>/dev/null
fi

# Disable updates for nodes whose original repo owner is gone (name up for grabs)
disable_dead_node() {
    node_dir="ComfyUI/custom_nodes/$1"
    if [ ! -f "$node_dir/.git/config" ]; then
        return 0
    fi
    if ! grep -qi "$2" "$node_dir/.git/config"; then
        return 0
    fi
    if git -C "$node_dir" remote remove origin >/dev/null 2>&1; then
        echo -e "${YELLOW}[NOTICE]${RESET} Updates for $1 were disabled for security reasons."
        echo "         Its original repository was deleted and the name is free to be taken over by someone else."
        echo "         The node itself was left in place and keeps working."
    else
        echo -e "${YELLOW}[WARNING]${RESET} Could not remove the origin remote of $1."
    fi
}
disable_dead_node "ComfyUI-fish-audio-s2" "Saganaki22"
disable_dead_node "ComfyUI-Krea2T-Enhancer" "capitan01R"

echo -e "${GREEN}::::::::::::::: Updating All Nodes :::::::::::::::${RESET}"
echo ""
"$PYTHON_BIN" ComfyUI/custom_nodes/ComfyUI-Manager/cm-cli.py update all
echo ""

# Restoring Numpy 1.26.4
echo -e "${GREEN}::::::::::::::: Restoring${YELLOW} Numpy 1.26.4 ${GREEN}:::::::::::::::${RESET}"
echo ""
"$PYTHON_BIN" -m uv pip install --force-reinstall numpy==1.26.4 --no-deps $UV_ARGS
echo ""

echo -e "${GREEN}::::::::::::::: Done. Starting ComfyUI :::::::::::::::${RESET}"
echo ""
if [ -f "run_amd_gpu.sh" ] && { [ "$(cat .cei_gpu_backend 2>/dev/null)" = "amd" ] || "$PYTHON_BIN" -c "import torch,sys; sys.exit(0 if getattr(torch.version,'hip',None) else 1)" 2>/dev/null; }; then
    bash run_amd_gpu.sh
else
    bash run_nvidia_gpu.sh
fi
