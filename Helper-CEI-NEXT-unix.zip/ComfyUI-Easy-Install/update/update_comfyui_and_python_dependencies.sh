#!/bin/bash

cd "$(dirname "$0")"

# Locate embedded Python
PYTHON=""
if [ -f "../python_embeded/python" ]; then
  PYTHON="../python_embeded/python"
elif [ -f "../python_embeded/bin/python3" ]; then
  PYTHON="../python_embeded/bin/python3"
elif [ -f "../python_embeded/bin/python" ]; then
  PYTHON="../python_embeded/bin/python"
else
  echo "ERROR: Embedded Python not found!"
  exit 1
fi

bash update_comfyui.sh nopause

echo "-"
echo "This will try to update pytorch and all python dependencies."
echo "-"
echo "If you just want to update normally, close this and run update_comfyui.sh instead."
echo "-"
read -p "Press any key to continue..."

if "$PYTHON" -c "import torch,sys; sys.exit(0 if getattr(torch.version,'hip',None) else 1)" 2>/dev/null; then
  ROCM_VERSION="${CEI_ROCM_VERSION:-7.2}"
  echo "ROCm install detected - keeping the ROCm wheel index (rocm${ROCM_VERSION})"
  "$PYTHON" -m uv pip install --upgrade torch torchvision torchaudio \
    --index-url "https://download.pytorch.org/whl/rocm${ROCM_VERSION}" \
    -r ../ComfyUI/requirements.txt pygit2
else
  "$PYTHON" -m uv pip install --upgrade torch torchvision torchaudio -r ../ComfyUI/requirements.txt pygit2
fi

read -p "Press any key to continue..."
